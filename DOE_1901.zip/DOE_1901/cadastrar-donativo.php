<?php
session_start();
//arquivo de conexão com o banco de dados
include_once("connect.php");

$dataCadastroDonativo = $_POST['dataCadastroDonativo'];
$nome_donativo = $_POST['nome_donativo'];
$descricao = $_POST['descricao_donativo'];
$qtdeItem = $_POST['qtdeItem'];
$entrega = $_POST['entregaSouN'];
$novo_usado = $_POST['novo_usado'];
$categoria = $_POST['nome_categoria'];

//variáveis com arquivos do upload
$fotoDonativo = $_FILES['fotoDonativo']['name'];

//local das imagens dos usuários cadastrados
//$pasta = $email;

//criar pasta em php com base em uma verificação
/*if(file_exists("produtos/".$pasta)){
	
	echo "<a href='cadastrar-donativo.php'>Retornar para a tela de cadastro</a><br>";
	
} else {

	mkdir("produtos/".$pasta,0777);
}*/

//upload das imagens
//move_uploaded_file($_FILES['fotoDonativo']['tmp_name'],"users/".$pasta."/".$fotoDonativo);//função para salvar foto dentro da pasta users e depois por @email.com


//envia dados ao banco
$sql = "insert into tb_donativo (dataCadastroDonativo,nome_donativo,descricao_donativo,qtdeItem,entregaSouN,novo_usado,nome_categoria,fotoDonativo)values
(NOW(),'$nome_donativo','$descricao','$qtdeItem','$entrega','$novo_usado','$categoria','$fotoDonativo');";
$enviar=mysqli_query($link,$sql);

if ($enviar){
    $_SESSION['mensagem'] = "<p style='color:green;'> Donativo Cadastrado</p>";
    header("Location: minha-caixa.php");
    exit;
} else {
    $_SESSION['mensagem']= "<p style='color:green;'> Erro ao cadastrar donativo </p>";
    header("Location: minha-caixa.php");
    exit;
}


?>