<?php
SESSION_START();

//arquivo de conexão com o banco de dados
include "connect.php";

$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$cep = $_POST['cep'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$senha = $_POST['senha'];
$dica = $_POST['dica'];
$cadastrar = false;


//variáveis com arquivos do upload
$fotoPerfil = $_FILES['fotoPerfil']['name'];


//verificar se é possível cadastrar
if($nome != "" && $sobrenome != "" && $cep != "" && $email != "" && $telefone != "" && $senha != "" && $dica != "" && $fotoPerfil != ""){
	$cadastrar = true;
} else {
	$_SESSION['status'] = "$nome, preencha com todos os dados pedidos<br>";	
	header("location:cadastre-usuario.php");
	//echo "Preencha com todos os dados pedidos<br>";
	//echo "<a href='cadastre-usuario.php'>Voltar</a><br>";
}


//local das imagens dos usuários cadastrados
$pasta = $email;


//criar pasta em php com base em uma verificação
if(file_exists("users/".$pasta)){
	$_SESSION['status'] = "$nome, você já possui login com este e-mail<br>";	
	header("location:cadastre-usuario.php"); //volta pra tela de cadastro caso já possua uma pasta com o mesmo email cadastrado
} else { //se não existir email cadastrado cria nova pasta
	mkdir("users/".$pasta,0777);
}

//upload das imagens
move_uploaded_file($_FILES['fotoPerfil']['tmp_name'],"users/".$pasta."/".$fotoPerfil);//função para salvar foto dentro da pasta users e depois por @email.com


//envia dados ao banco
if($cadastrar) {
    $sql = "insert into tb_user(nome,sobrenome,cep,email,telefone,senha,dica,fotoPerfil)values
    ('$nome','$sobrenome','$cep','$email','$telefone','$senha','$dica','$fotoPerfil');";
    mysqli_query($link,$sql);
    echo "<a href='login.php'>Retornar para o Login</a><br>";
}




?>