<!---ARRUMEI AS CATEGORIAS E OS VALUES DENTRO DAS CATEGORIAS-->

<!DOCTYPE html>
<html lang="pt-br">
    <meta charset="utf-8">
	
    <?php
    session_start();

    include "cabecalho.inc.php";

    include_once "connect.php"; 
    if(!empty($_SESSION['mensagem'])){
        echo $_SESSION['mensagem'];
        unset($_SESSION['mensagem']);
    }

    ?>
		
	</div>
	</header>
	<body>
        <br><br>
            <div class="card-top" style="margin-top: 8%;">
                <h2 class="title"> <strong>O que você quer doar ou receber?</strong></h2>
            </div>

        <form class="form" action="cadastrar-donativo.php" method="post" enctype="multipart/form-data"> <!-- enctype para utilizar vários tipos de arquivos -->
			<div class="card">
		
                <div class="card-group">
                    <input type="text" name="nome_donativo" placeholder="Nome do produto" required>
                </div>

                <div class="card-group">                
                    <input type="text" name="descricao_donativo" placeholder="Descrição" required>
                </div>

                <div class="card-group">
                    
                    <input type="text" name="qtdeItem" placeholder="Quantidade" required>
                </div>

                <div class="card-group radio">
                <label> Esse item é Novo ou Usado? </label>
                    <label>
                        <input type="radio" name="novo_usado" value="N"> Novo <br>
                        <input type="radio" name="novo_usado" value="U"> Usado <br>  
                    </label>   
                </div>

                <div class="card-group">
                    <label> Qual a categoria desta doação? </label>
                        <select name="nome_categoria">
                            <option value="0">Roupa, Mesa e Banho</option>
                            <option value="1">Calçados</option>
                            <option value="2">Produtos de Higiene</option>
                            <option value="3">Brinquedos</option>
                            <option value="4">Móveis e Eletrodomésticos</option>
                            <option value="5">Utensílios</option>
                            <option value="6">Eletrônicos</option>
                            <option value="7">Itens infantis</option>
                            <option value="8">Alimentos/Cesta Básica</option>
                            <option value="9">Materiais de Construção</option>
                            <option value="10">Outros</option>
                            
                        </select>                     
                </div>

                <br><br>
                <div class="card-group">
                    
                <label>Fotos 
                <input type="file" name="fotoDonativo" accept="image/*" required>
                </label> <br>
                
</div>
                <div class="card-group radio">
                    <label> Eu posso pegar ou entregar este item? </label>
                    <label>
                        <input type="radio" name="entregaSouN" value="S"> Sim <br>
                        <input type="radio" name="entregaSouN" value="N"> Não <br>
                        <input type="radio" name="entregaSouN" value="SN"> Podemos negociar <br>
                    </label>
                </div>


                <br><br>

				<div class="card-group btn">
                    <button type="submit" name="enviar"> <strong>Salvar</strong> </button>   
				</div> 

				<br>

                <div class="card-group btnTenhoConta">
                    <a href="#"><strong>Excluir</strong></a>
                </div> 

                <br>
			</div>  
        </form>

    <div class="voltar_login">
        <a href="index.php"> Voltar </a>
    </div>

</body>

</html>