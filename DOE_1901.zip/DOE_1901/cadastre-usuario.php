<!DOCTYPE html>
<html lang="pt-br">
    <meta charset="utf-8">
	
    <?php
    session_start();
    include "cabecalho.inc.php";
    
    ?>
		
	</div>
	</header>
	<body>

        <form class="form" action="cadastrar-usuario.php" method="post" enctype="multipart/form-data"> <!-- enctype para utilizar vários tipos de arquivos -->
			<div class="card" style="margin-top: 8%;">
				<div class="card-top">

                    <h2 class="title">Olá!</h2><br>
                        <p>Crie a sua conta</p>

                </div><br><br><br>
                
                <div class="card-top">
                    <label> Escolha uma foto de perfil</label> <br><br>
                    <img class="imglogin" src="imagem/user.png" alt="Selecione uma imagem" id="imgPhoto"><br>
                    <input type="file" id="fotoPerfil" name="fotoPerfil" accept="image/*" required>
                </div>
                <script src="js/script.js"></script>
                
                <br>

                <div class="card-group">
                    <label> Nome </label>
                    <input type="text" name="nome" placeholder="Digite seu nome" required>
                </div>

                <div class="card-group">
                    <label> Sobrenome </label>
                    <input type="text" name="sobrenome" placeholder="Digite seu sobrenome" required>
                </div>

                <div class="card-group">                
                    <label> Onde você está? </label>
                    <input type="text" name="cep" placeholder="Seu CEP: 00000000" required>
                </div>

                <div class="card-group">
                    <label> Número de telefone com DDD </label>
                    <input type="text" name="telefone" placeholder="XX 9XXXX-XXXX" required>
                </div>

                <div class="card-group">
                    <label> E-mail</label>
                    <input type="text" name="email" placeholder="Email para fazer login" required>
                </div>

                <div class="card-group">
                    <label> Senha </label>                    
                    <input type="password" name="senha" placeholder="Senha" required>
                </div>

                <div class="card-group">
                    <label> Dica </label>
                    <input type="text" name="dica" placeholder="Digite uma dica para lembrar a sua senha" required>
                </div>

                <br>

				<div class="card-group btn">
                    <button type="submit"> <strong>Cadastrar</strong> </button>  
				</div> 

				<br>

                <div class="card-group btnTenhoConta">
                    <a href="login.php"><strong>Tenho uma conta</strong></a>
                </div> 

                <br>

                <?php
                if(isset($_SESSION['status']))
                {
                    ?>
                        <div class="alert" role="alert">
                            <strong> Olá </strong> <?php echo $_SESSION['status']; ?> 
                        </div>     
               <?php
                    unset($_SESSION['status']);
                }
                ?>

            <br>
			</div>  
        </form>
</body>

</html>