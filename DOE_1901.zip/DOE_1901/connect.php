<?php

//arquivo de conexao com o banco
$host = "localhost";
$user = "root";
$pass = "";
$banco = "db_doe";

$link = mysqli_connect($host,$user,$pass,$banco);
if ($link){

}else{
    echo "Erro de conexão no banco de dados";
}

?>