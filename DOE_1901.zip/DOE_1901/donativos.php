<?php

include "cabecalho.inc.php";

?>


<div class="container" style="margin-top: 8%;">

<div id="donativo-area">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <h3 class="main-title">Categorias</h3>
            </div>
            <div class="col-md-12" id="filter-btn-box">
              <button class="main-btn filter-btn active" id="all-btn">Todos</button>
              <button class="main-btn filter-btn" id="rou-btn">Roupas, Mesa e Banho</button>
              <button class="main-btn filter-btn" id="cal-btn">Calçados</button>
              <button class="main-btn filter-btn" id="hig-btn">Produtos de higiene</button>
              <button class="main-btn filter-btn" id="brq-btn">Brinquedos</button>
              <button class="main-btn filter-btn" id="mov-btn">Móveis e Eletrodomésticos</button>
              <button class="main-btn filter-btn" id="ut-btn">Utensílios</button>
              <button class="main-btn filter-btn" id="el-btn">Eletrônicos</button>
              <button class="main-btn filter-btn" id="inf-btn">Itens infantis</button>
              <button class="main-btn filter-btn" id="ali-btn">Alimentos/Cesta Básica</button>
              <button class="main-btn filter-btn" id="mat-btn">Materiais de Construção</button>
              <button class="main-btn filter-btn" id="out-btn">Outros</button>
            </div>
            <div class="col-md-3 project-box rou">
            <a href="roupas.php"><img src="imagem/roupas.png" class="img-fluid" alt="Projeto 1">
            </div>
            <div class="col-md-3 project-box cal">
            <a href="calcados.php"><img src="imagem/sapatos.png" class="img-fluid" alt="Projeto 2">
            </div>
            <div class="col-md-3 project-box hig">
            <a href="higiene.php"><img src="imagem/higiene.png" class="img-fluid" alt="Projeto 3">
            </div>
            <div class="col-md-3 project-box brq">
            <a href="brinquedos.php"><img src="imagem/brinquedos.png" class="img-fluid" alt="Projeto 3">
            </div>
            <div class="col-md-3 project-box mov">
            <a href="moveis.php"><img src="imagem/moveis.png" class="img-fluid" alt="Projeto 5">
            </div>
            <div class="col-md-3 project-box ut">
            <a href="utensilios.php"><img src="imagem/utensilios.png" class="img-fluid" alt="Projeto 6">
              </div>
            <div class="col-md-3 project-box el">
            <a href="eletronicos.php"><img src="imagem/eletronicos.png" class="img-fluid" alt="Projeto 7">
              </div>
            <div class="col-md-3 project-box inf">
            <a href="infantil.php"><img src="imagem/infantil.png" class="img-fluid" alt="Projeto 8">
              </div>
            <div class="col-md-3 project-box ali">
            <a href="alimentos.php"><img src="imagem/alimentos.png" class="img-fluid" alt="Projeto 9">
              </div>
            <div class="col-md-3 project-box mat">
            <a href="materiais.php"><img src="imagem/materiais.png" class="img-fluid" alt="Projeto 10">
              </div>
            <div class="col-md-3 project-box out">
            <a href="outros.php"><img src="imagem/outros.png" class="img-fluid" alt="Projeto 11">
              </div>
            </div>
          </div>
        </div>
      </div>
</div>
      <script src="js/script.js"></script>
  