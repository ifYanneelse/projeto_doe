<!DOCTYPE html>
<html lang="pt-br">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php

include "cabecalho.inc.php";

?>

<body>

<div class="container-fluid">
          <div id="mainSlider" class="carousel slide" data-ride="carousel">
              <ol class="carousel-indicators">
                  <li data-target="#mainSldies" data-slide-to="0" class="active"></li>
                  <li data-target="#mainSldies" data-slide-to="1"></li>
                  <li data-target="#mainSldies" data-slide-to="2"></li>
              </ol>
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="imagem/banner1.png" class="d-block w-100" alt="banner1">
      
                  <!-- tirar classe d-none -->
             
                  <div class="carousel-caption d-md-block">
                    <h2>Sabe aquele presente que você ganhou e até hoje não usou porque ainda não sabe como utilizá-lo?</h5>
                    <h4>Aquela roupa guardada a anos dentro do armário que você já enjoou de tanto usar? Ou até mesmo aquele par de tênis antigo que você não usa mais?</h4>
                      <p>Pois é, talvez todas essas coisas não te interessem mais, mas com com certeza existe alguém que precisa!</p>
                     
                  </div>
                </div>
                <div class="carousel-item">
                  <img src="imagem/banner2.png" class="d-block w-100" alt="banner2">
                  <div class="carousel-caption d-md-block">
                    <h2>Faça a diferença! Contribua com uma doação de algum produto que você não queira mais, para àqueles que necessitam!</h5>
                    <p</p>
                    
                  </div>
                </div>
                
                <div class="carousel-item"> 
                <img src="imagem/banner3.png" class="d-block w-100" alt="banner3">
                <div class="card-img-overlay">
          <form class="form" action="logando.php" method="post">        
			    
          <div class="card">
				    <div class="card-top">
					    <h2 class="title">Olá!</h2><br>
				    	<p>Acesse a sua conta</p>
				  </div>
          <br>
          <br>
				<div class="card-group">
					<label> E-mail </label>
          <input type="email" name="email" placeholder="Digite seu e-mail" required>
				</div>
				<div class="card-group">
					<label> Senha </label>                    
					<input type="password" name="senha" placeholder="Digite sua senha" required>
				</div>
  

				<!--<div class="card-group btnEsq">
					<a href="esqueci.php">Esqueci a senha</a>
				</div>-->
				          
				<div class="card-group btn"> 
          <button type="submit"> <strong>Entrar</strong> </button>  
				</div>  
				
				<div class="card-group btnCriar">
					<a href="cadastre-usuario.php"><strong>Criar conta</strong></a>
				</div>  
				<br>
        </form>
			</div>        
             </div>
            </div>
          </div>
          <a href="#mainSlider" class="carousel-control-prev" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
          </a>
          <a href="#mainSlider" class="carousel-control-next" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
        </div>

</body>
</html>