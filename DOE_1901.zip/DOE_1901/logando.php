<?php

//arquivo de login
include "connect.php";

//iniciar session
SESSION_START();

$email = $_POST["email"];
$senha = $_POST["senha"];

//variáveis de sessão | para criar arrays
$_SESSION['email_user'] = $email;
$_SESSION['senha_user'] = $senha;

if(isset($_SESSION['email_user']) && isset($_SESSION['senha_user'])){
    $sql = mysqli_query($link,"select * from tb_user WHERE email = '$email'");              //consulta
    
    while($dados = mysqli_fetch_array($sql)){ //fetch_array procura dentro de um array      //varredura
        $email = $dados['email'];                                                           //guarda dentro das novas variáveis
        $senha = $dados['senha'];                                                           //a variável passa a ser array, os índices passam a ser o nome dos campos: email e senha
    }
    //verificar se os dados batem com o que temos na tabela do banco de dados
    //início da verificação
    if($email == $email && $senha == $senha){
        header('location:minha-conta.php'); //talvez colocar depois minha-caixa.php - cai direto página do perfil do usuário
    } else {
        header('location:login.php');
    }
    // fim verificação
} else {
    header('location:login.php');
}

?>