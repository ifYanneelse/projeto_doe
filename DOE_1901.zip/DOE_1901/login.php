<!DOCTYPE html>
<html lang="pt-br">
	<meta charset="utf-8">
		
	<?php

    include "cabecalho.inc.php";
    
    ?>

	<body>


		<form class="form" action="logando.php" method="post">
			<div class="card" style="margin-top: 8%;">
				<div class="card-top">
			
					<h2 class="title">Olá!</h2><br>
					<p>Acesse a sua conta</p>
				</div><br><br>

				<div class="card-group">
					<label> E-mail </label>
               		<input type="email" name="email" placeholder="Digite seu e-mail" required>
				</div>

				<div class="card-group">
					<label> Senha </label>                    
					<input type="password" name="senha" placeholder="Digite sua senha" required>
				</div>         

				<!--<div class="card-group btnEsq">
					<a href="esqueci.php">Esqueci a senha</a>
				</div>-->
				
                <br>
				<div class="card-group btn">
                	<button type="submit"> <strong>Entrar</strong> </button>  
				</div>  
				<br>

				<div class="card-group btnCriar">
					<a href="cadastre-usuario.php"><strong>Criar conta</strong></a>
				</div>  

				<br>

			</div>  
		</form>

</body>

</html>