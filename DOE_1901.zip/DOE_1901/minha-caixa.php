<!DOCTYPE html>
<html lang="pt-br">
    <meta charset="utf-8">
	
    <?php

    include "cabecalho.inc.php";

    ?>
		
	</div>
	</header>
	<body>
        <br><br>
            <div class="card-top">
                <h2 class="title"> <strong>Minha conta</strong></h2>
            </div>

            <div class="card">

                <br><br>
                
				<div class="card-group btn">
                    <a href="cadastre-donativo.php"><strong>Adicionar item</strong></a>
                </div> 

                <br>
			</div>  

</body>

</html>